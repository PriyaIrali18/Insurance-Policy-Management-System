package com.project.insurance.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    // http://localhost:9122/insurance/
    @GetMapping("/")
    public String home() {
        return "dashboard";
    }
}

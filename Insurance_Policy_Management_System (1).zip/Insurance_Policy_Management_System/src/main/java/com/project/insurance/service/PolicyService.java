package com.project.insurance.service;

import java.util.List;

import com.project.insurance.entity.Policy;

public interface PolicyService {

    Policy savePolicy(Policy p);

    List<Policy> getAllPolicies();

    List<Policy> searchPolicies(String keyword);

    Policy getPolicyById(Long id);

    void deletePolicy(Long id);
}

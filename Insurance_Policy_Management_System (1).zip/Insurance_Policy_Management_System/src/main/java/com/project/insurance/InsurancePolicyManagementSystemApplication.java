package com.project.insurance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsurancePolicyManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsurancePolicyManagementSystemApplication.class, args);
	}

}

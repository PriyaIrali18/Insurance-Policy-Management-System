package com.project.insurance.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.project.insurance.entity.Policy;
import com.project.insurance.service.PolicyService;

@Controller
@RequestMapping("/policies")
public class PolicyController {

    private final PolicyService service;

    public PolicyController(PolicyService service) {
        this.service = service;
    }

    // LIST + SEARCH
    @GetMapping
    public String listPolicies(@RequestParam(required = false) String keyword,
                               Model model) {
        model.addAttribute("policies", service.searchPolicies(keyword));
        model.addAttribute("keyword", keyword);
        return "policies";   // policies.html
    }

    // ADD FORM
    @GetMapping("/new")
    public String showForm(Model model) {
        model.addAttribute("policy", new Policy());
        return "policy-form";
    }

    // EDIT FORM
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {
        Policy p = service.getPolicyById(id);
        if (p == null) {
            return "redirect:/policies";
        }
        model.addAttribute("policy", p);
        return "policy-form";
    }

    // SAVE (ADD / UPDATE)
    @PostMapping("/save")
    public String save(@ModelAttribute Policy policy, Model model) {
        service.savePolicy(policy);
        model.addAttribute("msg", "Policy saved successfully!");
        model.addAttribute("policy", new Policy());   // reset form
        return "policy-form";
    }

    // DELETE
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.deletePolicy(id);
        return "redirect:/policies";
    }
}

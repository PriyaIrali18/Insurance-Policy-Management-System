package com.project.insurance.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.project.insurance.entity.Policy;
import com.project.insurance.repository.PolicyRepository;
import com.project.insurance.service.PolicyService;

@Service
public class PolicyServiceImpl implements PolicyService {

    private final PolicyRepository repo;

    public PolicyServiceImpl(PolicyRepository repo) {
        this.repo = repo;
    }

    @Override
    public Policy savePolicy(Policy p) {
        return repo.save(p);
    }

    @Override
    public List<Policy> getAllPolicies() {
        return repo.findAll();
    }

    @Override
    public List<Policy> searchPolicies(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return repo.findAll();
        }
        return repo.search(keyword.trim());
    }

    @Override
    public Policy getPolicyById(Long id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public void deletePolicy(Long id) {
        repo.deleteById(id);
    }
}

package com.project.insurance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.project.insurance.entity.Policy;

public interface PolicyRepository extends JpaRepository<Policy, Long> {

    @Query("SELECT p FROM Policy p " +
           "WHERE LOWER(p.policyHolderName) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "   OR LOWER(p.policyNumber)     LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "   OR LOWER(p.insuranceType)    LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Policy> search(@Param("keyword") String keyword);
}
